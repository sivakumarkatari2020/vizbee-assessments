import { useState, useEffect } from 'react';
import { Layout,Row, Col, Button, Card, Modal, Progress  } from 'antd';
import { AudioOutlined, PauseOutlined } from '@ant-design/icons';
import Webcam from 'react-webcam';

import './App.css';

const { Header, Content , Footer } = Layout;

const App = () => {
  const [timer, setTimer] = useState(60); // Set timer to 60 seconds
  const [isRecording, setIsRecording] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [audioChunks, setAudioChunks] = useState([]);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [audioBlob, setAudioBlob] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [elapsedMin,setElapsedMin] = useState(0);
  const [animation,setAnimation] = useState(false);

  useEffect(() => {
    // Decrement timer every second
    const interval = setInterval(() => {
      setTimer((prevTimer) => prevTimer - 1);
    }, 1000);

    // Clear interval when timer reaches 0
    if (timer === 0) {
      // Handle logic for when timer reaches 0
      setCurrentQuestion((prevQuestion) => prevQuestion + 1);
      setTimer(60);
      setElapsedTime(0);
      setElapsedMin(0);
      setIsRecording(false);
      setAnimation(false);
    }

    // Clean up interval on component unmount
    return () => clearInterval(interval);
  }, [timer]);

  // UseEffect hook to update the elapsed time every second when recording is on
  useEffect(() => {
    let intervalId;
    if (isRecording) {
      intervalId = setInterval(() => {
        setElapsedTime(prevTime => prevTime + 1);
      }, 1000);
    }

    if(elapsedTime === 60){
      setElapsedMin(prevState => prevState + 1);
      setElapsedTime(0);
    }

    return () => clearInterval(intervalId);
  }, [isRecording]);

  const handleRecordClick = async () => {
    setIsRecording(true);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    setMediaRecorder(mediaRecorder);
    mediaRecorder.addEventListener("dataavailable", handleDataAvailable);
    mediaRecorder.start();
    setAnimation(true);
  };

  const handleStopClick = () => {
    setIsRecording(false);
    setAnimation(false);
    mediaRecorder.stop();
  };

  const handleDataAvailable = (event) => {
    setAudioChunks((prev) => [...prev, event.data]);
  };

  const handleNextClick = () => {
    // Make API request to get next question and send current audio file
    // Update state with new question and reset timer
    const blob = new Blob(audioChunks, { type: "audio/ogg; codecs=opus" });
    setAudioBlob(blob);
    if(currentQuestion < 9){
      setCurrentQuestion((prevQuestion) => prevQuestion + 1);
      setTimer(60);
    } else {
      setShowConfirmation(true);
    }
    setAudioChunks([]);
    setIsRecording(false);
    setElapsedMin(0);
    setElapsedTime(0);
    setAnimation(false);
  };

  const handleFinishClick = () => {
    setShowConfirmation(true);
    setIsRecording(false);
    setAnimation(false);
  };

  const handleConfirm = () => {
    // Make API request to submit exam and redirect to result page
    setShowConfirmation(false);

    const blob = new Blob(audioChunks, { type: "audio/ogg; codecs=opus" });
    setAudioBlob(blob);
    console.log("Audio blob:", blob);
  };

  const handleCancel = () => {
    setShowConfirmation(false);
  };

  const webcamOptions = {
    height: 180,
    width: 400,
    screenshotFormat: 'image/jpeg',
    videoConstraints: {
      facingMode: 'user',
    },
  };

  const questions = [
    "What is React and what are its advantages?",
    "What are the differences between React and other JavaScript frameworks?",
    "How can you create a stateless component in React?",
    "What is the virtual DOM in React and how does it work?",
    "What are React Hooks and how do they work?",
    "How do you pass data between parent and child components in React?",
    "What is JSX and how does it differ from HTML?",
    "How do you handle events in React?",
    "What are the benefits of using Redux in a React application?",
    "What are the best practices for optimizing React application performance?"
  ]

  return (
    <Layout>
      <Header>
        <Row>
          <Col span={8}>
            <h1>Vizbee</h1>
          </Col>
        </Row>
      </Header>

      <div className="app-wrapper">
        <Content>
          <Row>
            <Col span={12}>
              <Webcam {...webcamOptions} />
            </Col>
          </Row>
          <Row>
            <Col>
              <Card>
                <div className="row-flexer">
                  <p>{questions[currentQuestion]}</p>
                  <p className="timer">Timer: {timer}</p>
                </div>
                <div className="audio-animation">
                  {
                    animation
                    ? <div className="animation running">
                      <span className="first"></span>
                      <span className="second"></span>
                      <span className="third"></span>
                      <span className="fourth"></span>
                      <span className="fifth"></span>
                    </div>
                    : <div className="animation">
                      <span className="first"></span>
                      <span className="second"></span>
                      <span className="third"></span>
                      <span className="fourth"></span>
                      <span className="fifth"></span>
                    </div>
                  }
                  <p>0{elapsedMin}:{elapsedTime}</p>
                </div>
                <Button.Group>
                  {isRecording ? (
                    <Button onClick={handleStopClick}>Stop</Button>
                    ) : (
                      <Button onClick={handleRecordClick}>Record</Button>
                      )}
                  <Button onClick={handleNextClick}>Next</Button>
                  <Button onClick={handleFinishClick}>Finish</Button>
                </Button.Group>
              </Card>
            </Col>
          </Row>
          <Modal
            title="Confirm submission"
            visible={showConfirmation}
            onOk={handleConfirm}
            onCancel={handleCancel}
            >
            <p>Are you sure you want to submit your exam?</p>
          </Modal>
        </Content>

        <div className="instruction-box">
          <h3>Instructions</h3>
        </div>
      </div>

      <Footer>
        Vizbee App ©2023 | All rights reserved.
      </Footer>
    </Layout>
  );
};

export default App;